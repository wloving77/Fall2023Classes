#!/bin/bash

egrep -r '^FAILURE' results | sed 's/:FAILURE//g' > /tmp/fails.txt

/bin/rm -f /tmp/tests.txt
touch /tmp/tests.txt
cat /tmp/fails.txt | while read line
do
#   echo "-------------------------------------------"
#   echo $line
   f=`echo $line gawk '{print $1}'`
#   echo $f
   gawk '/TESTING/{split($5,R,"/"); resultsDir=R[1] "/" R[2]; V="scripts/runTest.sh " $2 " " $3 " " resultsDir; system(V); exit}' $f
done
