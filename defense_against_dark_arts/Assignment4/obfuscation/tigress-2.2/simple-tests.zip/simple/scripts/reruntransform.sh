#!/bin/bash

transform=$1

find results/single/$1 -type f > /tmp/fails1.txt
find results/dual/$1 -type f > /tmp/fails2.txt
cat /tmp/fails1.txt  /tmp/fails2.txt > /tmp/fails.txt

/bin/rm -f /tmp/tests.txt
touch /tmp/tests.txt
for f in `cat /tmp/fails.txt`
do
   gawk '/^TESTING/{split($5,R,"/"); resultsDir=R[1] "/" R[2]; C="/bin/rm " $0"; scripts/runTest.sh " $2 " " $3 " " resultsDir; print "EXEC " C; system(C); exit}' $f 
done

#for test in `cat /tmp/tests.txt`
#do
#      echo "TEST='$test'"
#      IFS=" "
#      args=($test)
 #     echo "${args[0]} : ${args[1]}"
#      scripts/runTest.sh ${args[0]} ${args[1]} 
#done
