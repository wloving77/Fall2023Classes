#!/bin/bash 

/bin/rm -f *.c exe

source "../types.sh"

number=0

##################################################################
# generate C programs
##################################################################
function generate() {
   for_intTypes_and_intTypes_do cast1
   for_intTypes_and_floatTypes_do cast1
   for_floatTypes_and_intTypes_do cast1
}

##################################################################
# main()
##################################################################
function main() {
   generate
   execute
}

##################################################################
# run
##################################################################
main
exit 0
