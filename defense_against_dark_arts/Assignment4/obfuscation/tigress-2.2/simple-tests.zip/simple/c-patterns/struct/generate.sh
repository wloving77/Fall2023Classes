#!/bin/bash 

/bin/rm -f *.c exe

source "../types.sh"

number=0

##################################################################
# void foo(TYPE x)
##################################################################


##################################################################
# generate C programs
##################################################################
function generate() {
   for_intTypes_do struct1
   for_single_do struct2
   for_intTypes_do array1
   for_intTypes_do array2
   for_intTypes_and_intTypes_do union1
   for_intTypes_do array3
   for_enumType_do array4
}

##################################################################
# main()
##################################################################
function main() {
   generate
   execute
}

##################################################################
# run
##################################################################
main
exit 0
