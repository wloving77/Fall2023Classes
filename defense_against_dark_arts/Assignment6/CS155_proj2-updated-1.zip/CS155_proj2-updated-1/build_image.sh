docker build -t cs155-proj2-image .
